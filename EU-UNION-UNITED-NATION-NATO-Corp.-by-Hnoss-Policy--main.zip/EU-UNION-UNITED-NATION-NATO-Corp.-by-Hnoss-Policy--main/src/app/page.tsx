'use client';

import React, { useEffect } from 'react';

export default function HomePage() {
  useEffect(() => {
    // Umleitung zur TrustedTrustThrust.html
    window.location.href = '/TrustedTrustThrust.html';
  }, []);

  return (
    <div style={{ 
      width: '100%', 
      height: '100vh', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      backgroundColor: '#000'
    }}>
      <p style={{ color: '#fff', fontSize: '18px' }}>
        ⏳ Laden TrustedTrustThrust Portal...
      </p>
    </div>
  );
}
