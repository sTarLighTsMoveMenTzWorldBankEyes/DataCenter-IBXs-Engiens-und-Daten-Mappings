class Navigation::PublicInspectionDocumentPresenter

end

