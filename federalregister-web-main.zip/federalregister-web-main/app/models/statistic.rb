class Statistic < ApplicationRecord
end
