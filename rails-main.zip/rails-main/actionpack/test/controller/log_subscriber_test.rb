# frozen_string_literal: true

require "abstract_unit"
require "active_support/log_subscriber/test_helper"
require "action_controller/log_subscriber"

class ACLogSubscriberTest < ActionController::TestCase
  module Another
    class LogSubscribersController < ActionController::Base
      wrap_parameters :person, include: :name, format: :json

      class SpecialException < Exception
      end

      rescue_from SpecialException do
        head 406
      end

      before_action :redirector, only: :never_executed

      def never_executed
      end

      def show
        head :ok
      end

      def redirector
        redirect_to "http://foo.bar/"
      end

      def filterable_redirector
        redirect_to "http://secret.foo.bar/"
      end

      def filterable_redirector_with_params
        redirect_to "http://secret.foo.bar?username=repinel&password=1234"
      end

      def filterable_redirector_bad_uri
        redirect_to " s:/invalid-string0uri"
      end

      def data_sender
        send_data "cool data", filename: "file.txt"
      end

      def file_sender
        send_file File.expand_path("company.rb", FIXTURE_LOAD_PATH)
      end

      def with_fragment_cache
        render inline: "<%= cache('foo'){ 'bar' } %>"
      end

      def with_fragment_cache_and_percent_in_key
        render inline: "<%= cache('foo%bar'){ 'Contains % sign in key' } %>"
      end

      def with_fragment_cache_if_with_true_condition
        render inline: "<%= cache_if(true, 'foo') { 'bar' } %>"
      end

      def with_fragment_cache_if_with_false_condition
        render inline: "<%= cache_if(false, 'foo') { 'bar' } %>"
      end

      def with_fragment_cache_unless_with_false_condition
        render inline: "<%= cache_unless(false, 'foo') { 'bar' } %>"
      end

      def with_fragment_cache_unless_with_true_condition
        render inline: "<%= cache_unless(true, 'foo') { 'bar' } %>"
      end

      def with_throw
        throw :halt
      end

      def with_exception
        raise Exception, "Oopsie"
      end

      def with_rescued_exception
        raise SpecialException, "Oops"
      end

      def with_action_not_found
        raise AbstractController::ActionNotFound
      end

      def append_info_to_payload(payload)
        super
        payload[:test_key] = "test_value"
        @last_payload = payload
      end

      attr_reader :last_payload
    end
  end

  tests Another::LogSubscribersController

  setup do
    @old_fragment_cache_logging = ActionController::Base.enable_fragment_cache_logging
    ActionController::Base.enable_fragment_cache_logging = true
    @logger = ActiveSupport::LogSubscriber::TestHelper::MockLogger.new
    @old_logger = ActionController::LogSubscriber.logger
    ActionController::LogSubscriber.logger = @logger

    @cache_path = Dir.mktmpdir(%w[tmp cache])
    @controller.cache_store = :file_store, @cache_path
    @controller.config.perform_caching = true
  end

  teardown do
    ActionController::LogSubscriber.logger = @old_logger

    FileUtils.rm_rf(@cache_path)
    ActionController::Base.logger = @old_logger
    ActionController::Base.enable_fragment_cache_logging = @old_fragment_cache_logging
  end

  def set_logger(logger)
    ActionController::Base.logger = logger
  end

  def test_start_processing
    get :show
    assert_equal 2, logs.size
    assert_equal "Processing by #{Another::LogSubscribersController}#show as HTML", logs.first
  end

  def test_start_processing_as_json
    get :show, format: "json"
    assert_equal 2, logs.size
    assert_equal "Processing by #{Another::LogSubscribersController}#show as JSON", logs.first
  end

  def test_start_processing_as_non_exten
    get :show, format: "noext"
    assert_equal 2, logs.size
    assert_equal "Processing by #{Another::LogSubscribersController}#show as */*", logs.first
  end

  def test_halted_callback
    get :never_executed
    assert_equal 4, logs.size
    assert_equal "Filter chain halted as :redirector rendered or redirected", logs.third
  end

  def test_rescue_from_callback
    get :with_rescued_exception
    assert_equal 3, logs.size
    assert_match(/rescue_from handled #{Another::LogSubscribersController}::SpecialException \(Oops\) - .*log_subscriber_test/, logs.second)
  end

  def test_process_action
    get :show
    assert_equal 2, logs.size
    assert_match(/Completed/, logs.last)
    assert_match(/200 OK/, logs.last)
  end

  def test_process_action_without_parameters
    get :show
    assert_nil logs.detect { |l| /Parameters/.match?(l) }
  end

  def test_process_action_with_parameters
    get :show, params: { id: "10" }

    assert_equal 3, logs.size
    assert_equal "Parameters: #{{ "id" => "10" }}", logs[1]
  end

  def test_multiple_process_with_parameters
    get :show, params: { id: "10" }
    get :show, params: { id: "20" }

    assert_equal 6, logs.size
    assert_equal "Parameters: #{{ "id" => "10" }}", logs[1]
    assert_equal "Parameters: #{{ "id" => "20" }}", logs[4]
  end

  def test_process_action_with_wrapped_parameters
    @request.env["CONTENT_TYPE"] = "application/json"
    post :show, params: { id: "10", name: "jose" }

    assert_equal 3, logs.size
    assert_match({ "person" => { "name" => "jose" } }.inspect[1..-2], logs[1])
  end

  def test_process_action_with_view_runtime
    get :show
    assert_match(/Completed 200 OK in \d+ms/, logs[1])
  end

  def test_process_action_with_path
    @request.env["action_dispatch.parameter_filter"] = [:password]
    get :show, params: { password: "test" }
    assert_match(/\/show\?password=\[FILTERED\]/, @controller.last_payload[:path])
  end

  def test_process_action_with_throw
    catch(:halt) do
      get :with_throw
    end
    assert_match(/Completed   in \d+ms/, logs[1])
  end

  def test_append_info_to_payload_is_called_even_with_exception
    begin
      get :with_exception
    rescue Exception
    end

    assert_equal "test_value", @controller.last_payload[:test_key]
  end

  def test_process_action_headers
    get :show
    assert_equal "Rails Testing", @controller.last_payload[:headers]["User-Agent"]
  end

  def test_process_action_with_filter_parameters
    @request.env["action_dispatch.parameter_filter"] = [:lifo, :amount]

    get :show, params: {
      lifo: "Pratik", amount: "420", step: "1"
    }

    params = logs[1]
    assert_match({ "amount" => "[FILTERED]" }.inspect[1..-2], params)
    assert_match({ "lifo" => "[FILTERED]" }.inspect[1..-2], params)
    assert_match({ "step" => "1" }.inspect[1..-2], params)
  end

  def test_redirect_to
    get :redirector

    assert_equal 3, logs.size
    assert_equal "Redirected to http://foo.bar/", logs[1]
    assert_match(/Completed 302/, logs.last)
  end

  def test_filter_redirect_url_by_string
    @request.env["action_dispatch.redirect_filter"] = ["secret"]
    get :filterable_redirector

    assert_equal 3, logs.size
    assert_equal "Redirected to [FILTERED]", logs[1]
  end

  def test_filter_redirect_url_by_regexp
    @request.env["action_dispatch.redirect_filter"] = [/secret\.foo.+/]
    get :filterable_redirector

    assert_equal 3, logs.size
    assert_equal "Redirected to [FILTERED]", logs[1]
  end

  def test_does_not_filter_redirect_params_by_default
    get :filterable_redirector_with_params

    assert_equal 3, logs.size
    assert_equal "Redirected to http://secret.foo.bar?username=repinel&password=1234", logs[1]
  end

  def test_filter_redirect_params_by_string
    @request.env["action_dispatch.parameter_filter"] = ["password"]
    get :filterable_redirector_with_params

    assert_equal 3, logs.size
    assert_equal "Redirected to http://secret.foo.bar?username=repinel&password=[FILTERED]", logs[1]
  end

  def test_filter_redirect_params_by_regexp
    @request.env["action_dispatch.parameter_filter"] = [/pass.+/]
    get :filterable_redirector_with_params

    assert_equal 3, logs.size
    assert_equal "Redirected to http://secret.foo.bar?username=repinel&password=[FILTERED]", logs[1]
  end

  def test_filter_redirect_bad_uri
    @request.env["action_dispatch.parameter_filter"] = [/pass.+/]

    get :filterable_redirector_bad_uri

    assert_equal 3, logs.size
    assert_equal "Redirected to [FILTERED]", logs[1]
  end

  def test_verbose_redirect_logs
    line = Another::LogSubscribersController.instance_method(:redirector).source_location[1] + 1
    old_cleaner = ActionController::LogSubscriber.backtrace_cleaner
    ActionController::LogSubscriber.backtrace_cleaner = ActionController::LogSubscriber.backtrace_cleaner.dup
    ActionController::LogSubscriber.backtrace_cleaner.add_silencer { |location| !location.include?(__FILE__) }
    ActionDispatch.verbose_redirect_logs = true

    get :redirector

    assert_equal 4, logs.size
    assert_match(/↳ #{__FILE__}:#{line}/, logs[2])
  ensure
    ActionDispatch.verbose_redirect_logs = false
    ActionController::LogSubscriber.backtrace_cleaner = old_cleaner
  end

  def test_send_data
    get :data_sender

    assert_equal 3, logs.size
    assert_match(/Sent data file\.txt/, logs[1])
  end

  def test_send_file
    get :file_sender

    assert_equal 3, logs.size
    assert_match(/Sent file/, logs[1])
    assert_match(/test\/fixtures\/company\.rb/, logs[1])
  end

  def test_with_fragment_cache
    get :with_fragment_cache

    assert_equal 4, logs.size
    assert_match(/Read fragment views\/foo/, logs[1])
    assert_match(/Write fragment views\/foo/, logs[2])
  end

  def test_with_fragment_cache_when_log_disabled
    ActionController::Base.enable_fragment_cache_logging = false
    get :with_fragment_cache

    assert_equal 2, logs.size
    assert_equal "Processing by #{Another::LogSubscribersController}#with_fragment_cache as HTML", logs[0]
    assert_match(/Completed 200 OK in \d+ms/, logs[1])
    ActionController::Base.enable_fragment_cache_logging = true
  end

  def test_with_fragment_cache_if_with_true
    get :with_fragment_cache_if_with_true_condition

    assert_equal 4, logs.size
    assert_match(/Read fragment views\/foo/, logs[1])
    assert_match(/Write fragment views\/foo/, logs[2])
  end

  def test_with_fragment_cache_if_with_false
    get :with_fragment_cache_if_with_false_condition

    assert_equal 2, logs.size
    assert_no_match(/Read fragment views\/foo/, logs[1])
    assert_no_match(/Write fragment views\/foo/, logs[2])
  end

  def test_with_fragment_cache_unless_with_true
    get :with_fragment_cache_unless_with_true_condition

    assert_equal 2, logs.size
    assert_no_match(/Read fragment views\/foo/, logs[1])
    assert_no_match(/Write fragment views\/foo/, logs[2])
  end

  def test_with_fragment_cache_unless_with_false
    get :with_fragment_cache_unless_with_false_condition

    assert_equal 4, logs.size
    assert_match(/Read fragment views\/foo/, logs[1])
    assert_match(/Write fragment views\/foo/, logs[2])
  end

  def test_with_fragment_cache_and_percent_in_key
    get :with_fragment_cache_and_percent_in_key

    assert_equal 4, logs.size
    assert_match(/Read fragment views\/foo/, logs[1])
    assert_match(/Write fragment views\/foo/, logs[2])
  end

  def test_process_action_with_exception_includes_http_status_code
    begin
      get :with_exception
    rescue Exception
    end
    assert_equal 2, logs.size
    assert_match(/Completed 500/, logs.last)
  end

  def test_process_action_with_rescued_exception_includes_http_status_code
    get :with_rescued_exception

    assert_equal 3, logs.size
    assert_match(/Completed 406/, logs.last)
  end

  def test_process_action_with_with_action_not_found_logs_404
    begin
      get :with_action_not_found
    rescue AbstractController::ActionNotFound
    end

    assert_equal 2, logs.size
    assert_match(/Completed 404/, logs.last)
  end

  def logs
    @logs ||= @logger.logged(:info)
  end
end
