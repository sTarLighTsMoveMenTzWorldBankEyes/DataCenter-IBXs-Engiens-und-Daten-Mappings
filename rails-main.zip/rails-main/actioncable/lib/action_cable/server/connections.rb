# frozen_string_literal: true

# :markup: markdown

module ActionCable
  module Server
    # # Action Cable Server Connections
    #
    # Collection class for all the connections that have been established on this
    # specific server. Remember, usually you'll run many Action Cable servers, so
    # you can't use this collection as a full list of all of the connections
    # established against your application. Instead, use RemoteConnections for that.
    module Connections # :nodoc:
      BEAT_INTERVAL = 3

      def connections = connections_map.values

      def each_connection(...)
        # Iterate a snapshot: the heartbeat, #restart and statistics all walk the
        # live connections while worker threads concurrently add/remove entries,
        # and mutating a Hash mid-iteration raises a RuntimeError.
        connections.each(...)
      end

      def add_connection(connection)
        connections_map[connection.object_id] = connection
      end

      def remove_connection(connection)
        connections_map.delete connection.object_id
      end

      # WebSocket connection implementations differ on when they'll mark a connection
      # as stale. We basically never want a connection to go stale, as you then can't
      # rely on being able to communicate with the connection. To solve this, a 3
      # second heartbeat runs on all connections. If the beat fails, we automatically
      # disconnect.
      def setup_heartbeat_timer
        @heartbeat_timer ||= executor.timer(BEAT_INTERVAL) do
          executor.post { each_connection(&:beat) }
        end
      end

      def open_connections_statistics
        each_connection.map(&:statistics)
      end

      private
        def connections_map
          @connections_map ||= {}
        end
    end
  end
end
